open module oinarria {

  requires java.sql;
  requires javafx.base;
  requires javafx.fxml;
  requires javafx.controls;

  exports ehu.isad;

}
